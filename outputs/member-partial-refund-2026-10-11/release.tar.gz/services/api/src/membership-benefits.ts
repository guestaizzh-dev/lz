import { BadRequestException, Body, ConflictException, Controller, ForbiddenException, Get, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Query, Req, UseGuards } from '@nestjs/common';
import { Type } from 'class-transformer';
import { IsInt, IsOptional, IsString, Length, Matches, Max, Min } from 'class-validator';
import { AdminGuard, UserGuard, requireRoles, type AuthRequest } from './auth.js';
import { Database } from './database.js';
import { membershipPlanView } from './membership-terms.js';
import type { Prisma } from './generated/prisma/client.js';

const chinaDay=(date:Date)=>new Date(new Date(date.getTime()+8*3600000).toISOString().slice(0,10)+'T00:00:00Z');
export function benefitWindow(startsAt:Date,endsAt:Date,periodKind:string,now:Date){
  const first=chinaDay(startsAt),last=chinaDay(new Date(endsAt.getTime()-1)),today=chinaDay(now);
  if(periodKind==='MEMBERSHIP')return{windowStart:first,windowEnd:last};
  if(periodKind==='DAY')return{windowStart:today,windowEnd:today};
  if(periodKind==='MONTH')return{windowStart:new Date(Math.max(first.getTime(),Date.UTC(today.getUTCFullYear(),today.getUTCMonth(),1))),windowEnd:new Date(Math.min(last.getTime(),Date.UTC(today.getUTCFullYear(),today.getUTCMonth()+1,0)))};
  throw new ConflictException('权益额度周期配置无效，请联系书院');
}
export async function membershipContentTier(versionId:string|null,store:Pick<Database,'$queryRaw'>){
  if(!versionId)return 0;
  const rows=await store.$queryRaw<{parameters:unknown}[]>`SELECT b.parameters FROM "PlanBenefit" b JOIN "BenefitDefinition" d ON d.id=b."definitionId" WHERE b."planVersionId"=${versionId} AND d.code='CONTENT_ACCESS' AND NOT EXISTS(SELECT 1 FROM "BenefitScope" s WHERE s."planBenefitId"=b.id)`;
  const tier=(rows[0]?.parameters as {contentTier?:number}|undefined)?.contentTier;
  return Number.isInteger(tier)&&tier!>=0&&tier!<=3?tier!:0;
}
// A pending refund suspends only its purchased period, without rewriting its dates or grant source.
export async function membershipRefundHolds(userId:string,store:Pick<Database,'$queryRaw'>){
  const rows=await store.$queryRaw<{id:string}[]>`SELECT DISTINCT m.id FROM "Membership" m JOIN "TradeOrderItem" i ON i.id=m."orderItemId" JOIN "RefundItem" ri ON ri."orderItemId"=i.id JOIN "Refund" r ON r.id=ri."refundId" JOIN "PaymentTransaction" p ON p.id=r."paymentTransactionId" WHERE m."userId"=${userId} AND m.source='PURCHASE' AND m."grantKey"='membership.payment:'||p.id AND p.disposition='ACCEPTED' AND ri."revokeQuantity">0 AND r.state IN ('APPROVED','REFUNDING','FAILED')`;
  return rows.map(row=>row.id);
}
class PageQuery { @IsOptional() @Type(()=>Number) @IsInt() @Min(1) page=1; @IsOptional() @Type(()=>Number) @IsInt() @Min(1) @Max(50) size=20; }
class ContentBenefitsDto { @IsInt() @Min(1) expectedVersion!:number; @IsInt() @Min(0) @Max(3) contentTier!:number; @IsString() @Length(2,500) @Matches(/\S/) reason!:string; }
type QuotaSource={periodId:string|null;grantId:string|null;definitionId:string;parameters:Prisma.JsonValue;quota:number;periodKind:string;startsAt:Date;endsAt:Date;planVersionId:string|null;planBenefitId:string|null;resourceId:string|null;offerId:string|null};

@Injectable()
export class MembershipBenefitsService {
  constructor(private readonly db:Database){}
  private async sources(tx:Prisma.TransactionClient,userId:string,definitionId:string,now:Date){
    const suspended=await membershipRefundHolds(userId,tx);
    const members=await tx.membership.findMany({where:{userId,revokedAt:null,id:{notIn:suspended},startsAt:{lte:now},endsAt:{gt:now}},orderBy:{endsAt:'asc'}}),sources:QuotaSource[]=[];
    for(const member of members){const benefit=await tx.planBenefit.findFirst({where:{planVersionId:member.planVersionId!,definitionId}});if(benefit?.quota!==null&&benefit?.quota!==undefined)sources.push({periodId:member.id,grantId:null,definitionId,parameters:benefit.parameters,quota:benefit.quota,periodKind:benefit.periodKind,startsAt:member.startsAt,endsAt:member.endsAt,planVersionId:member.planVersionId,planBenefitId:benefit.id,resourceId:null,offerId:null});}
    const grants=await tx.benefitGrant.findMany({where:{userId,definitionId,revokedAt:null,startsAt:{lte:now},endsAt:{gt:now}},orderBy:{endsAt:'asc'}});
    for(const grant of grants)sources.push({periodId:null,grantId:grant.id,definitionId,parameters:grant.parametersSnapshot,quota:grant.quota,periodKind:'MEMBERSHIP',startsAt:grant.startsAt,endsAt:grant.endsAt,planVersionId:null,planBenefitId:null,resourceId:grant.resourceId,offerId:grant.offerId});
    return sources;
  }
  private async used(tx:Prisma.TransactionClient,userId:string,source:QuotaSource,window:ReturnType<typeof benefitWindow>){
    return (await tx.benefitUsage.aggregate({where:{userId,periodId:source.periodId,grantId:source.grantId,definitionId:source.definitionId,...window,state:{in:['HELD','CONSUMED']}},_sum:{quantity:true}}))._sum.quantity??0;
  }
  // The owning business workflow supplies its transaction. There is no client endpoint that can fabricate usage.
  async hold(tx:Prisma.TransactionClient,userId:string,code:string,businessKey:string,quantity=1,context:{resourceId?:string;offerId?:string;categoryCode?:string}={}){
    if(!Number.isSafeInteger(quantity)||quantity<1||quantity>1000000||!businessKey.trim()||businessKey.length>200)throw new BadRequestException('权益用量或业务编号无效');
    if(!(await tx.$queryRaw<{id:string}[]>`SELECT id FROM "User" WHERE id=${userId} AND status='ACTIVE' FOR UPDATE`).length)throw new ForbiddenException('账号不可用');
    const definition=await tx.benefitDefinition.findUnique({where:{code}});if(!definition||definition.kind!=='QUOTA')throw new BadRequestException('此权益不支持额度占用');
    const scope={resourceId:context.resourceId??null,offerId:context.offerId??null,categoryCode:context.categoryCode??null},old=await tx.benefitUsage.findFirst({where:{userId,businessKey}});
    if(old){const prior=(old.parametersSnapshot as {scope?:typeof scope}).scope;if(old.definitionId!==definition.id||old.quantity!==quantity||prior?.resourceId!==scope.resourceId||prior?.offerId!==scope.offerId||prior?.categoryCode!==scope.categoryCode)throw new ConflictException('同一业务编号不能改变权益、范围或数量');return old;}
    const now=new Date();
    for(const source of await this.sources(tx,userId,definition.id,now)){
      if(source.resourceId&&source.resourceId!==scope.resourceId||source.offerId&&source.offerId!==scope.offerId)continue;
      if(source.planBenefitId){const scopes=await tx.benefitScope.findMany({where:{planBenefitId:source.planBenefitId}});if(scopes.length&&!scopes.some(s=>s.resourceId&&s.resourceId===scope.resourceId||s.offerId&&s.offerId===scope.offerId||s.categoryCode&&s.categoryCode===scope.categoryCode))continue;}
      const window=benefitWindow(source.startsAt,source.endsAt,source.periodKind,now),used=await this.used(tx,userId,source,window);
      if(source.quota-used<quantity)continue;
      return tx.benefitUsage.create({data:{userId,periodId:source.periodId,grantId:source.grantId,definitionId:definition.id,...window,quantity,businessKey,state:'HELD',parametersSnapshot:{code,scope,parameters:source.parameters,quota:source.quota,periodKind:source.periodKind,planVersionId:source.planVersionId,startsAt:source.startsAt.toISOString(),endsAt:source.endsAt.toISOString()}}});
    }
    throw new ConflictException('此权益当前不可用或剩余额度不足');
  }
  async finish(tx:Prisma.TransactionClient,userId:string,id:string,action:'CONSUMED'|'RELEASED'|'REVERSED'){
    await tx.$queryRaw`SELECT id FROM "User" WHERE id=${userId} FOR UPDATE`;
    const row=await tx.benefitUsage.findFirst({where:{id,userId}});if(!row)throw new NotFoundException('权益用量记录不存在');
    if(row.state===action)return row;
    if(!(row.state==='HELD'&&['CONSUMED','RELEASED'].includes(action)||row.state==='CONSUMED'&&action==='REVERSED'))throw new ConflictException('权益已经处理，不能重复消费或恢复');
    // Confirmed reservations survive period expiry; cancellation/refund belongs to the reserving workflow.
    return tx.benefitUsage.update({where:{id},data:{state:action,updatedAt:new Date(),version:{increment:1}}});
  }
  private async attach(versionIds:string[],store:Database|Prisma.TransactionClient=this.db){
    const benefits=await store.planBenefit.findMany({where:{planVersionId:{in:versionIds}},orderBy:{createdAt:'asc'}}),definitions=await store.benefitDefinition.findMany({where:{id:{in:benefits.map(b=>b.definitionId)}}});
    return benefits.map(b=>({...b,definition:definitions.find(d=>d.id===b.definitionId)!}));
  }
  async versions(planId:string,q:PageQuery){
    if(!await this.db.membershipPlan.findUnique({where:{id:planId}}))throw new NotFoundException('会员套餐不存在');
    return this.db.$transaction(async tx=>{const rows=await tx.membershipPlanVersion.findMany({where:{planId},orderBy:{releaseNo:'desc'},take:q.size,skip:(q.page-1)*q.size}),benefits=await this.attach(rows.map(v=>v.id),tx);return{items:rows.map(v=>({...v,benefits:benefits.filter(b=>b.planVersionId===v.id)})),total:await tx.membershipPlanVersion.count({where:{planId}})};},{isolationLevel:'RepeatableRead'});
  }
  async changeContent(planId:string,req:AuthRequest,dto:ContentBenefitsDto){
    requireRoles(req,['ADMIN']);
    return this.db.$transaction(async tx=>{
      const initial=await tx.membershipPlan.findUnique({where:{id:planId}});if(!initial)throw new NotFoundException('会员套餐不存在');
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended(${`membership.plan:${initial.tier}:${initial.days}`},0))`;
      const plan=await tx.membershipPlan.findUniqueOrThrow({where:{id:planId}});if(plan.version!==dto.expectedVersion)throw new ConflictException('套餐版本已变化，请刷新');
      if(dto.contentTier>plan.tier)throw new BadRequestException('内容访问层级不能超过套餐层级');
      const original=await tx.membershipPlanVersion.findUniqueOrThrow({where:{id:plan.currentVersionId!}}),benefits=await tx.planBenefit.findMany({where:{planVersionId:original.id}}),definition=await tx.benefitDefinition.findUniqueOrThrow({where:{code:'CONTENT_ACCESS'}});
      const range=['不包含会员文章与课程','入门及以下会员文章与课程','进阶及以下会员文章与课程','全部已发布会员文章与课程'][dto.contentTier];
      const description=`有效期${plan.days}天。此版本内容权益：${range}，以实际会员内容目录为准；独立付费内容、咨询、直播、实物和活动不包含在基础内容权益中。`;
      const latest=await tx.membershipPlanVersion.aggregate({where:{planId},_max:{releaseNo:true}});
      const next=await tx.membershipPlanVersion.create({data:{planId,releaseNo:(latest._max.releaseNo??0)+1,tier:plan.tier,days:plan.days,description,termsSnapshot:{title:plan.title,price:plan.price,currency:'CNY',durationDays:plan.days,contentTier:dto.contentTier},publishedAt:new Date()}});
      await tx.planBenefit.createMany({data:[...benefits.filter(b=>b.definitionId!==definition.id).map(b=>({planVersionId:next.id,definitionId:b.definitionId,parameters:b.parameters as Prisma.InputJsonValue,quota:b.quota,periodKind:b.periodKind})),{planVersionId:next.id,definitionId:definition.id,parameters:{contentTier:dto.contentTier},quota:null,periodKind:'MEMBERSHIP'}]});
      await tx.$executeRaw`INSERT INTO "BenefitScope"("planBenefitId","resourceId","offerId","categoryCode") SELECT nb.id,s."resourceId",s."offerId",s."categoryCode" FROM "BenefitScope" s JOIN "PlanBenefit" ob ON ob.id=s."planBenefitId" JOIN "PlanBenefit" nb ON nb."planVersionId"=${next.id} AND nb."definitionId"=ob."definitionId" WHERE ob."planVersionId"=${original.id}`;
      const updated=await tx.membershipPlan.update({where:{id:planId},data:{description,currentVersionId:next.id,version:{increment:1},updatedAt:new Date()}});
      await tx.auditLog.create({data:{actorId:req.actor.id,action:'membership.benefits.version',resource:'membershipPlan',resourceId:planId,reason:dto.reason,changes:{oldVersion:original.id,newVersion:next.id,contentTier:dto.contentTier}}});return updated;
    });
  }
  async summary(userId:string,q:PageQuery){
    return this.db.$transaction(async tx=>{
      const now=new Date(),suspended=await membershipRefundHolds(userId,tx),members=await tx.membership.findMany({where:{userId,revokedAt:null,endsAt:{gt:now}},include:{plan:true},orderBy:{startsAt:'asc'},take:50}),versions=await tx.membershipPlanVersion.findMany({where:{id:{in:members.flatMap(m=>m.planVersionId?[m.planVersionId]:[])}}}),benefits=await this.attach(versions.map(v=>v.id),tx);
      const items=await tx.benefitUsage.findMany({where:{userId},orderBy:[{createdAt:'desc'},{id:'desc'}],take:q.size,skip:(q.page-1)*q.size}),grants=await tx.benefitGrant.findMany({where:{userId,revokedAt:null,startsAt:{lte:now},endsAt:{gt:now}}}),definitions=await tx.benefitDefinition.findMany({where:{id:{in:[...items.map(u=>u.definitionId),...benefits.map(b=>b.definitionId),...grants.map(g=>g.definitionId)]}}}),quotas=[];
      for(const definition of definitions.filter(d=>d.kind==='QUOTA'))for(const source of await this.sources(tx,userId,definition.id,now)){
        const window=benefitWindow(source.startsAt,source.endsAt,source.periodKind,now),used=await this.used(tx,userId,source,window);
        quotas.push({name:definition.name,code:definition.code,periodId:source.periodId,grantId:source.grantId,quota:source.quota,used,remaining:Math.max(0,source.quota-used),periodKind:source.periodKind,...window});
      }
      return{memberships:members.map(m=>({id:m.id,source:m.source,startsAt:m.startsAt,endsAt:m.endsAt,state:suspended.includes(m.id)?'REFUND_PENDING':m.startsAt>now?'QUEUED':'ACTIVE',planVersionId:m.planVersionId,plan:membershipPlanView(m.plan,versions.find(v=>v.id===m.planVersionId)),benefits:benefits.filter(b=>b.planVersionId===m.planVersionId).map(b=>({code:b.definition.code,name:b.definition.name,parameters:b.parameters,quota:b.quota,periodKind:b.periodKind}))})),membershipTotal:await tx.membership.count({where:{userId,revokedAt:null,endsAt:{gt:now}}}),quotas,usage:{items:items.map(u=>({...u,name:definitions.find(d=>d.id===u.definitionId)?.name??'历史权益'})),total:await tx.benefitUsage.count({where:{userId}})}};
    },{isolationLevel:'RepeatableRead'});
  }
}
@Controller('learning/benefits') @UseGuards(UserGuard) export class MembershipBenefitsController {
  constructor(private readonly benefits:MembershipBenefitsService){}
  @Get() summary(@Req() req:AuthRequest,@Query() q:PageQuery){return this.benefits.summary(req.actor.id,q);}
}
@Controller('admin/membership-benefits') @UseGuards(AdminGuard) export class MembershipBenefitsAdminController {
  constructor(private readonly benefits:MembershipBenefitsService){}
  @Get('plans/:id') versions(@Param('id',ParseUUIDPipe) id:string,@Query() q:PageQuery){return this.benefits.versions(id,q);}
  @Post('plans/:id/content') change(@Param('id',ParseUUIDPipe) id:string,@Req() req:AuthRequest,@Body() dto:ContentBenefitsDto){return this.benefits.changeContent(id,req,dto);}
  @Get('users/:id') summary(@Param('id',ParseUUIDPipe) id:string,@Query() q:PageQuery){return this.benefits.summary(id,q);}
}
