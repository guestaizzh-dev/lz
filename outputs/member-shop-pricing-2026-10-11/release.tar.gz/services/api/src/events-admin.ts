import { BadRequestException, Body, ConflictException, Controller, Get, Injectable, Param, ParseUUIDPipe, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { IsInt, IsISO8601, IsString, Length, Matches, Max, Min } from 'class-validator';
import { Database } from './database.js';
import { AdminGuard, requireRoles, type AuthRequest } from './auth.js';
import { TableQuery, TransitionDto } from './admin.js';
import type { PublishStatus } from './generated/prisma/client.js';

class EventDto {
  @IsString() @Length(1,150) title!:string;
  @IsString() @Length(1,5000) description!:string;
  @IsString() @Length(1,40) category!:string;
  @IsString() @Matches(/^(https:\/\/[^\s]+|\/static\/art\/[a-z-]+\.svg)$/) cover!:string;
  @IsString() @Length(1,200) location!:string;
  @IsISO8601() startsAt!:string;
  @IsISO8601() endsAt!:string;
  @IsInt() @Min(1) @Max(100000) capacity!:number;
  @IsInt() @Min(0) @Max(100000000) price!:number;
}
class EventEditDto extends EventDto {
  @IsInt() @Min(1) expectedVersion!:number;
}
@Injectable()
export class EventsAdmin {
  constructor(private readonly db:Database) {}
  async list(query:TableQuery) {
    const where={...(query.status?{status:query.status}:{}),...(query.q?{OR:[{title:{contains:query.q,mode:'insensitive' as const}},{id:query.q}]}:{})};
    const [items,total]=await this.db.$transaction([this.db.event.findMany({where,orderBy:[{updatedAt:'desc'},{id:'desc'}],skip:(query.page-1)*query.size,take:query.size}),this.db.event.count({where})]);
    return {items,total};
  }
  async save(req:AuthRequest,dto:EventDto|EventEditDto,id?:string) {
    requireRoles(req,['OPERATOR']);
    if(new Date(dto.endsAt)<=new Date(dto.startsAt)||!dto.title.trim()||!dto.description.trim()||!dto.location.trim())throw new BadRequestException('请填写活动资料，结束时间须晚于开始时间');
    const {expectedVersion:_,...data}=dto as EventEditDto;
    return this.db.$transaction(async tx=>{
      let event;
      if(id){
        const changed=await tx.event.updateMany({where:{id,version:(dto as EventEditDto).expectedVersion,status:{in:['DRAFT','REJECTED']}},data:{...data,startsAt:new Date(data.startsAt),endsAt:new Date(data.endsAt),version:{increment:1}}});
        if(!changed.count)throw new ConflictException('活动版本或状态已变化；已发布活动需先下架');
        event=await tx.event.findUniqueOrThrow({where:{id}});
      }else event=await tx.event.create({data:{...data,startsAt:new Date(data.startsAt),endsAt:new Date(data.endsAt),responsibleUserId:req.actor.id}});
      await tx.auditLog.create({data:{actorId:req.actor.id,action:id?'event.edit':'event.create',resource:'event',resourceId:event.id,requestId:req.requestId??'',changes:{title:event.title,version:event.version}}});
      return event;
    });
  }
  async transition(req:AuthRequest,id:string,dto:TransitionDto) {
    requireRoles(req,['publish','reject'].includes(dto.action)?['MODERATOR']:['OPERATOR']);
    if(dto.reason.trim().length<1)throw new BadRequestException('请填写操作原因');
    const states:Record<string,{from:PublishStatus[];to:PublishStatus}>={submit:{from:['DRAFT','REJECTED'],to:'REVIEW'},publish:{from:['REVIEW'],to:'PUBLISHED'},reject:{from:['REVIEW'],to:'REJECTED'},archive:{from:['PUBLISHED'],to:'ARCHIVED'},revise:{from:['ARCHIVED','REJECTED'],to:'DRAFT'}};
    const state=states[dto.action]!;
    return this.db.$transaction(async tx=>{
      const event=await tx.event.findUnique({where:{id}});
      if(!event||event.version!==dto.expectedVersion||!state.from.includes(event.status))throw new ConflictException('活动状态或版本已变化，请刷新');
      if(['submit','publish'].includes(dto.action)&&event.endsAt<=new Date())throw new BadRequestException('已结束活动不能提交或发布');
      if(dto.action==='revise'&&await tx.eventRegistration.count({where:{ticketTypeId:{in:(await tx.eventTicketType.findMany({where:{sessionId:{in:(await tx.eventSession.findMany({where:{eventId:id},select:{id:true}})).map(row=>row.id)}},select:{id:true}})).map(row=>row.id)},state:{notIn:['CANCELLED','REFUNDED']}}}))throw new ConflictException('活动已有报名记录，不能修改已售活动资料；请创建新的活动');
      const changed=await tx.event.updateMany({where:{id,version:dto.expectedVersion,status:event.status},data:{status:state.to,version:{increment:1}}});
      if(!changed.count)throw new ConflictException('活动已被其他人更新，请刷新');
      await tx.auditLog.create({data:{actorId:req.actor.id,action:'event.'+dto.action,resource:'event',resourceId:id,requestId:req.requestId??'',reason:dto.reason,changes:{from:event.status,to:state.to,version:event.version+1}}});
      return {success:true};
    });
  }
}
@Controller('admin/events') @UseGuards(AdminGuard)
export class EventsAdminController {
  constructor(private readonly events:EventsAdmin) {}
  @Get() list(@Query() query:TableQuery) {return this.events.list(query);}
  @Post() create(@Req() req:AuthRequest,@Body() dto:EventDto) {return this.events.save(req,dto);}
  @Patch(':id') update(@Req() req:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() dto:EventEditDto) {return this.events.save(req,dto,id);}
  @Post(':id/transition') transition(@Req() req:AuthRequest,@Param('id',ParseUUIDPipe) id:string,@Body() dto:TransitionDto) {return this.events.transition(req,id,dto);}
}
