import { demoContentVisible } from './public-content.js';
import { BadRequestException, Body, ConflictException, Controller, ForbiddenException, Get, Injectable, NotFoundException, Param, ParseUUIDPipe, Post, Query, Req, UseGuards } from '@nestjs/common';
import { IsBoolean, IsIn, IsInt, IsOptional, IsUUID, Max, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { createHash } from 'node:crypto';
import { Database } from './database.js';
import { membershipPlanView } from './membership-terms.js';
import { membershipContentTier,membershipRefundHolds } from './membership-benefits.js';
import { OptionalUserGuard, UserGuard } from './auth.js';
import type { AuthRequest } from './auth.js';
import { Prisma } from './generated/prisma/client.js';

class ProgressDto {
  @IsUUID() eventId!: string;
  @IsInt() @Min(0) @Max(86400) positionSeconds!: number;
  @IsInt() @Min(0) @Max(30) elapsedSeconds!: number;
  @IsBoolean() completed!: boolean;
}
class LibraryQuery {
  @IsOptional() @IsUUID() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) size = 20;
  @IsOptional() @IsIn(['ALL','STUDYING','COMPLETED','EXPIRED']) filter = 'ALL';
}
type LibraryRow = { id: string; releaseId: string | null; access: string; started: boolean; finished: boolean; lastAt: Date | null };
type AccessStore = Pick<Database, 'course' | 'enrollment' | 'membership' | 'membershipPlanVersion' | 'featureConfig' | '$queryRaw'>;
@Injectable()
export class LearningService {
  constructor(private readonly db: Database) {}
  private async recordCompletion(userId:string,context:Awaited<ReturnType<LearningService['context']>>,tx:Prisma.TransactionClient){
    if(context.access==='TRIAL'||!context.releaseId)return null;
    const lessons=await tx.lesson.findMany({where:{releaseId:context.releaseId},include:{progress:{where:{userId}}}}),required=lessons.filter(l=>l.required),basis=required.length?required:lessons;
    if(!basis.length||basis.some(l=>!l.progress[0]?.completedAt))return null;
    const release=await tx.courseRelease.findUniqueOrThrow({where:{id:context.releaseId}});
    const completedAt=new Date(Math.max(...basis.map(l=>l.progress[0]!.completedAt!.valueOf())));
    return tx.courseCertificate.upsert({where:{userId_releaseId:{userId,releaseId:release.id}},create:{userId,courseId:context.course.id,releaseId:release.id,courseTitle:release.title,lessonCount:basis.length,completedAt},update:{}});
  }
  async certificate(courseId:string,userId:string){return this.db.$transaction(async tx=>{
    const users=await tx.$queryRaw<{id:string}[]>`SELECT id FROM "User" WHERE id=${userId} AND status='ACTIVE' FOR UPDATE`;
    if(!users.length)throw new ForbiddenException('请重新登录');
    const context=await this.context(courseId,userId,tx);if(context.access==='TRIAL')throw new ForbiddenException('加入课程后可查看研习完成记录');
    const row=await this.recordCompletion(userId,context,tx);
    if(!row)throw new BadRequestException('完成本版本全部必修章节后可查看研习完成记录');
    const {nickname}=await tx.user.findUniqueOrThrow({where:{id:userId},select:{nickname:true}});
    return{id:row.id,courseTitle:row.courseTitle,lessonCount:row.lessonCount,completedAt:row.completedAt,releaseId:row.releaseId,nickname};
  });}
  async summary(userId:string){
    const scope=!await demoContentVisible(this.db)?Prisma.sql`AND NOT c."isDemo" AND NOT t."isDemo"`:Prisma.empty;
    const [time,completed]=await this.db.$transaction([
      this.db.$queryRaw<{seconds:bigint;lessons:number}[]>`SELECT coalesce(sum(p."watchedSeconds"),0)::bigint AS seconds,count(*) FILTER(WHERE p."completedAt" IS NOT NULL)::int AS lessons FROM "StudyProgress" p JOIN "Lesson" l ON l.id=p."lessonId" JOIN "CourseRelease" r ON r.id=l."releaseId" JOIN "Course" c ON c.id=r."courseId" JOIN "Teacher" t ON t.id=c."teacherId" WHERE p."userId"=${userId} ${scope}`,
      this.db.$queryRaw<{courses:number}[]>`SELECT count(DISTINCT done."courseId")::int AS courses FROM (SELECT r."courseId",l."releaseId" FROM "Lesson" l JOIN "CourseRelease" r ON r.id=l."releaseId" JOIN "Course" c ON c.id=r."courseId" JOIN "Teacher" t ON t.id=c."teacherId" LEFT JOIN "StudyProgress" p ON p."lessonId"=l.id AND p."userId"=${userId} WHERE true ${scope} GROUP BY r."courseId",l."releaseId" HAVING CASE WHEN count(*) FILTER(WHERE l.required)>0 THEN bool_and(p."completedAt" IS NOT NULL) FILTER(WHERE l.required) ELSE bool_and(p."completedAt" IS NOT NULL) END) done`,
    ]);
    return{watchedSeconds:String(time[0]?.seconds??0n),completedLessons:time[0]?.lessons??0,completedCourses:completed[0]?.courses??0};
  }
  async plans() { return Promise.all((await this.db.membershipPlan.findMany({ where: { active: true }, orderBy: [{ tier: 'asc' }, { days: 'asc' }] })).map(async plan=>({...plan,contentTier:await membershipContentTier(plan.currentVersionId,this.db),purchaseReady:false,purchaseUnavailableReason:'会员真实支付与对应渠道产品尚未验收，暂不收取费用。',termLabel:plan.days===30?'月卡':plan.days===90?'季卡':'年卡',channelProducts:{ready:false,reason:'会员须接独立购买续费流程；iOS套餐须对应订阅产品，不能复用课程非消耗型映射。'}}))); }
  async membership(userId?: string, store: AccessStore = this.db) {
    if (!userId) return null;
    const now = new Date();
    const member=await store.membership.findFirst({ where: { userId, revokedAt: null, id:{notIn:await membershipRefundHolds(userId,store)}, startsAt: { lte: now }, endsAt: { gt: now } }, orderBy: { tier: 'desc' }, include: { plan: true } });
    if(!member)return null;
    const version=member.planVersionId?await store.membershipPlanVersion.findUnique({where:{id:member.planVersionId}}):null;
    return{...member,contentTier:await membershipContentTier(member.planVersionId,store),plan:membershipPlanView(member.plan,version)};
  }
  async context(courseId: string, userId?: string, store: AccessStore = this.db) {
    const course = await store.course.findUnique({ where: { id: courseId }, include: { teacher: true } });
    if (!course || (!await demoContentVisible(store) && (course.isDemo || course.teacher.isDemo))) throw new NotFoundException('课程不存在');
    const now = new Date();
    const enrollment = userId ? await store.enrollment.findFirst({ where: { courseId, userId, startsAt: { lte: now }, revokedAt: null, OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] } }) : null;
    const publicCourse = course.status === 'PUBLISHED' && course.teacher.status === 'PUBLISHED';
    if (!publicCourse && !enrollment) throw new NotFoundException('课程不存在或已下架');
    const member = publicCourse && course.membershipTier ? await this.membership(userId, store) : null;
    const memberAccess = !!member && member.contentTier >= (course.membershipTier ?? 4);
    return { course, releaseId: enrollment?.releaseId ?? course.publishedReleaseId, access: enrollment ? 'ENROLLED' : memberAccess ? 'MEMBER' : 'TRIAL', enrollment, publicCourse };
  }
  async curriculum(id: string, userId?: string) {
    const context = await this.context(id, userId);
    const release = context.releaseId ? await this.db.courseRelease.findFirst({ where: { id: context.releaseId, courseId: id }, include: { lessons: { orderBy: { position: 'asc' }, include: { progress: { where: { userId: userId ?? '' } } } } } }) : null;
    return { course: { id, title: release?.title ?? context.course.title, cover: context.course.cover, refundPolicy: (release?.refundPolicySnapshot as {text?:string}|undefined)?.text ?? context.course.refundPolicy, accessDays: release ? release.accessDays : context.course.accessDays }, access: context.access, releaseId: release?.id ?? null, deliveryBlocked:!!release?.withdrawnAt,deliveryReason:release?.withdrawalReason??null, lessons: release?.lessons.map(({ body: _, mediaId: __, sourceId: ___, progress, ...lesson }) => ({ ...lesson, accessible: !release.withdrawnAt&&(context.access !== 'TRIAL' || (context.publicCourse && lesson.trial)), progress: progress[0] ?? null })) ?? [] };
  }
  async lesson(id: string, userId?: string) {
    const lesson = await this.db.lesson.findUnique({ where: { id }, include: { release: true } });
    if (!lesson) throw new NotFoundException('章节不存在');
    if(lesson.release.withdrawnAt)throw new ForbiddenException('此版本停止交付，请在课程学习页选择替代版本或从订单申请退课');
    const context = await this.context(lesson.release.courseId, userId);
    if (context.releaseId !== lesson.releaseId || (context.access === 'TRIAL' && (!context.publicCourse || !lesson.trial))) throw new ForbiddenException('请先获得课程权限，或选择试听章节');
    const progress = userId ? await this.db.studyProgress.findUnique({ where: { userId_lessonId: { userId, lessonId: id } } }) : null;
    return { lesson, context, progress };
  }
  async enroll(id: string, userId: string) {
    return this.db.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "User" WHERE id = ${userId} AND status = 'ACTIVE' FOR UPDATE`;
      await tx.$queryRaw`SELECT id FROM "Course" WHERE id = ${id} FOR SHARE`;
      const { course, releaseId, publicCourse } = await this.context(id, userId, tx);
      if (!publicCourse || course.price !== 0 || !releaseId) throw new BadRequestException('该课程需要购买或尚未发布章节');
      await tx.$queryRaw`SELECT id FROM "CourseRelease" WHERE id=${releaseId} FOR SHARE`;
      if((await tx.courseRelease.findUniqueOrThrow({where:{id:releaseId}})).withdrawnAt)throw new BadRequestException('此版本已停止交付，请选择其他课程');
      const existing = await tx.enrollment.findUnique({ where: { userId_courseId: { userId, courseId: id } } });
      if (existing) {
        if (existing.revokedAt || (existing.expiresAt && existing.expiresAt <= new Date())) throw new ForbiddenException('课程权限已撤销或到期，请联系书院');
        return existing;
      }
      return tx.enrollment.create({ data: { userId, courseId: id, releaseId, source: 'FREE', expiresAt: course.accessDays ? new Date(Date.now() + course.accessDays * 86400000) : null } });
    });
  }
  async markPaidAccess(lessonId:string,userId?:string){
    if(!userId)return;
    return this.db.$transaction(async tx=>{
      await tx.$queryRaw`SELECT id FROM "User" WHERE id=${userId} FOR UPDATE`;
      const lesson=await tx.lesson.findUniqueOrThrow({where:{id:lessonId}}),release=await tx.courseRelease.findUniqueOrThrow({where:{id:lesson.releaseId}});
      if(release.withdrawnAt)throw new ForbiddenException('课程版本已停止交付，请查看课程补偿方案');
      const context=await this.context(release.courseId,userId,tx);
      if(context.releaseId!==release.id||(context.access==='TRIAL'&&!lesson.trial))throw new ForbiddenException('课程权限已变化，请重新打开章节');
      if(lesson.trial||!context.enrollment?.orderItemId)return;
      const item=await tx.tradeOrderItem.findUniqueOrThrow({where:{id:context.enrollment.orderItemId}});
      const payment=await tx.paymentTransaction.findFirst({where:{orderId:item.orderId,disposition:'ACCEPTED'}});
      if(payment&&await tx.refund.findFirst({where:{orderId:item.orderId,paymentTransactionId:payment.id,state:{in:['APPROVED','REFUNDING']}}}))throw new ForbiddenException('课程正在办理退款，完成后可在购课订单查看结果');
      const startedAt=new Date(),snapshot=item.benefitSnapshot as {startedAt?:string};
      if(!snapshot.startedAt)await tx.tradeOrderItem.update({where:{id:item.id},data:{benefitSnapshot:{...snapshot,startedAt:startedAt.toISOString()}}});
      await tx.enrollment.updateMany({where:{id:context.enrollment.id,startedAt:null},data:{startedAt}});
    });
  }
  async library(userId: string, query: LibraryQuery = new LibraryQuery()) {
    const member = await this.membership(userId), showDemo = await demoContentVisible(this.db), current = new Date();
    const pool = Prisma.sql`WITH eligible AS (
      SELECT c.id, c."createdAt", CASE WHEN x.valid THEN e."releaseId" WHEN x.member THEN c."publishedReleaseId" ELSE e."releaseId" END AS "releaseId",
        CASE WHEN x.valid THEN 'ENROLLED' WHEN x.member THEN 'MEMBER' WHEN e."revokedAt" IS NOT NULL THEN 'REVOKED' WHEN e."startsAt">${current} THEN 'UPCOMING' ELSE 'EXPIRED' END AS access
      FROM "Course" c JOIN "Teacher" t ON t.id=c."teacherId" LEFT JOIN "Enrollment" e ON e."courseId"=c.id AND e."userId"=${userId}
      CROSS JOIN LATERAL (SELECT (e.id IS NOT NULL AND e."revokedAt" IS NULL AND e."startsAt"<=${current} AND (e."expiresAt" IS NULL OR e."expiresAt">${current})) AS valid,
        (c.status='PUBLISHED' AND t.status='PUBLISHED' AND c."membershipTier" IS NOT NULL AND c."membershipTier"<=${member?.contentTier ?? 0}) AS member) x
      WHERE (e.id IS NOT NULL OR x.member) AND (${showDemo} OR (NOT c."isDemo" AND NOT t."isDemo"))
    ), library AS (
      SELECT e.*, r."withdrawnAt" IS NOT NULL AS blocked, p.started, p.finished, p."lastAt" FROM eligible e LEFT JOIN "CourseRelease" r ON r.id=e."releaseId" CROSS JOIN LATERAL (
        SELECT coalesce(bool_or(s."watchedSeconds">0 OR s."positionSeconds">0 OR s."completedAt" IS NOT NULL),false) AS started,
          coalesce(CASE WHEN count(*) FILTER(WHERE l.required)>0 THEN bool_and(s."completedAt" IS NOT NULL) FILTER(WHERE l.required) ELSE bool_and(s."completedAt" IS NOT NULL) END,false) AS finished,
          max(s."updatedAt") AS "lastAt" FROM "Lesson" l LEFT JOIN "StudyProgress" s ON s."lessonId"=l.id AND s."userId"=${userId} WHERE l."releaseId"=e."releaseId"
      ) p
    )`;
    const filter = query.filter === 'STUDYING' ? Prisma.sql`started AND NOT finished AND NOT blocked AND access IN ('ENROLLED','MEMBER')` : query.filter === 'COMPLETED' ? Prisma.sql`finished` : query.filter === 'EXPIRED' ? Prisma.sql`access IN ('EXPIRED','REVOKED')` : Prisma.sql`true`;
    // UUID keyset is stable even if the previous record is removed or its progress changes.
    const [rows, totals, recent] = await this.db.$transaction([
      this.db.$queryRaw<LibraryRow[]>(Prisma.sql`${pool} SELECT * FROM library WHERE ${filter} AND (${query.cursor ?? null}::text IS NULL OR id>${query.cursor ?? null}) ORDER BY id LIMIT ${query.size + 1}`),
      this.db.$queryRaw<{ totalCourses: number; availableCourses: number; studyingCourses: number; finishedCourses: number; expiredCourses: number; filteredCourses: number }[]>(Prisma.sql`${pool} SELECT count(*)::int AS "totalCourses", count(*) FILTER(WHERE NOT blocked AND access IN ('ENROLLED','MEMBER'))::int AS "availableCourses", count(*) FILTER(WHERE started AND NOT finished AND NOT blocked AND access IN ('ENROLLED','MEMBER'))::int AS "studyingCourses", count(*) FILTER(WHERE finished)::int AS "finishedCourses", count(*) FILTER(WHERE access IN ('EXPIRED','REVOKED'))::int AS "expiredCourses", count(*) FILTER(WHERE ${filter})::int AS "filteredCourses" FROM library`),
      this.db.$queryRaw<LibraryRow[]>(Prisma.sql`${pool} SELECT * FROM library WHERE NOT blocked AND access IN ('ENROLLED','MEMBER') AND "lastAt" IS NOT NULL ORDER BY "lastAt" DESC,id LIMIT 1`),
    ], { isolationLevel: 'RepeatableRead' });
    const selected = rows.slice(0, query.size);
    const [courses, releases] = await Promise.all([
      this.db.course.findMany({ where: { id: { in: selected.map(row => row.id) } }, select: { id: true, title: true, cover: true, refundPolicy: true, accessDays: true } }),
      this.db.courseRelease.findMany({ where: { id: { in: selected.flatMap(row => row.releaseId ? [row.releaseId] : []) } }, include: { lessons: { orderBy: { position: 'asc' }, select: { id: true, title: true, position: true, format: true, durationSeconds: true, trial: true, required: true, progress: { where: { userId } } } } } }),
    ]);
    const items = selected.map(row => {
      const course = courses.find(item => item.id === row.id)!, release = releases.find(item => item.id === row.releaseId);
      const accessible = ['ENROLLED','MEMBER'].includes(row.access)&&!release?.withdrawnAt;
      return { course: { id: row.id, title: release?.title ?? course.title, cover: course.cover, refundPolicy: (release?.refundPolicySnapshot as { text?: string } | undefined)?.text ?? course.refundPolicy, accessDays: release ? release.accessDays : course.accessDays }, access: row.access, releaseId: row.releaseId, deliveryBlocked:!!release?.withdrawnAt,deliveryReason:release?.withdrawalReason??null,lessons: release?.lessons.map(({ progress, ...lesson }) => ({ ...lesson, accessible, progress: progress[0] ?? null })) ?? [] };
    });
    return { items, nextCursor: rows.length > query.size ? rows[query.size - 1]!.id : null, stats: totals[0]!, recentCourseId: recent[0]?.id ?? null, membershipActive: !!member };
  }
  async progress(id: string, userId: string, dto: ProgressDto) {
    const { lesson } = await this.lesson(id, userId);
    const payloadHash = createHash('sha256').update(JSON.stringify({ id, ...dto })).digest('hex');
    return this.db.$transaction(async tx => {
      await tx.$queryRaw`SELECT id FROM "User" WHERE id = ${userId} FOR UPDATE`;
      await tx.$queryRaw`SELECT id FROM "CourseRelease" WHERE id=${lesson.releaseId} FOR SHARE`;
      if((await tx.courseRelease.findUniqueOrThrow({where:{id:lesson.releaseId}})).withdrawnAt)throw new ForbiddenException('课程版本已停止交付，学习记录保留');
      const context = await this.context(lesson.release.courseId, userId, tx);
      if (context.releaseId !== lesson.releaseId || (context.access === 'TRIAL' && (!context.publicCourse || !lesson.trial))) throw new ForbiddenException('课程权限已变化，请重新打开章节');
      const event = await tx.studyEvent.findUnique({ where: { id: dto.eventId } });
      if (event) {
        if (event.userId !== userId || event.payloadHash !== payloadHash) throw new ConflictException('学习事件标识已用于其他操作');
        return event.result;
      }
      const old = await tx.studyProgress.findUnique({ where: { userId_lessonId: { userId, lessonId: id } } });
      const elapsed = Math.min(dto.elapsedSeconds, old ? Math.max(0, Math.floor((Date.now() - old.updatedAt.getTime()) / 1000)) : 0);
      const watchedSeconds = Math.min(lesson.durationSeconds, (old?.watchedSeconds ?? 0) + elapsed);
      const complete = lesson.format === 'TEXT' ? dto.completed : lesson.durationSeconds > 0 && watchedSeconds >= lesson.durationSeconds * 0.9;
      const data = { positionSeconds: Math.min(dto.positionSeconds, lesson.durationSeconds), watchedSeconds, completedAt: old?.completedAt ?? (complete ? new Date() : null) };
      const progress = await tx.studyProgress.upsert({ where: { userId_lessonId: { userId, lessonId: id } }, create: { userId, lessonId: id, ...data }, update: data });
      if(progress.completedAt)await this.recordCompletion(userId,context,tx);
      if(!old?.completedAt&&progress.completedAt){
        const businessDay=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'}),date=new Date(businessDay+'T00:00:00Z'),eventKey='lesson.complete:'+userId+':'+id;
        if(!await tx.growthLedger.findUnique({where:{eventKey}})){
          const gained=await tx.growthLedger.aggregate({where:{userId,businessDay:date,delta:{gt:0}},_sum:{delta:true}}),delta=Math.max(0,Math.min(2,20-(gained._sum.delta??0)));
          if(delta)await tx.growthLedger.create({data:{userId,delta,businessDay:date,eventKey,reason:'首次完成研习章节',sourceResourceId:lesson.release.courseId,ruleSnapshot:{growth:2,dailyLimit:20}}});
        }
      }
      const result = JSON.parse(JSON.stringify(progress));
      await tx.studyEvent.create({ data: { id: dto.eventId, userId, lessonId: id, payloadHash, result } });
      return result;
    });
  }
}
@Controller('learning')
export class LearningController {
  constructor(private readonly learning: LearningService) {}
  @Get('courses/:id') @UseGuards(OptionalUserGuard) curriculum(@Param('id', ParseUUIDPipe) id: string, @Req() req: AuthRequest) { return this.learning.curriculum(id, req.actor?.id); }
  @Get('lessons/:id') @UseGuards(OptionalUserGuard) async lesson(@Param('id', ParseUUIDPipe) id: string, @Req() req: AuthRequest) {
    const { lesson, progress } = await this.learning.lesson(id, req.actor?.id);
    if(lesson.format==='TEXT')await this.learning.markPaidAccess(id,req.actor?.id);
    const { mediaId: _, sourceId: __, release: ___, ...safe } = lesson;
    return { ...safe, hasMedia: !!lesson.mediaId, progress };
  }
  @Post('courses/:id/enroll') @UseGuards(UserGuard) enroll(@Param('id', ParseUUIDPipe) id: string, @Req() req: AuthRequest) { return this.learning.enroll(id, req.actor.id); }
  @Post('courses/:id/certificate') @UseGuards(UserGuard) certificate(@Param('id',ParseUUIDPipe) id:string,@Req() req:AuthRequest){return this.learning.certificate(id,req.actor.id);}
  @Get('library') @UseGuards(UserGuard) library(@Req() req: AuthRequest, @Query() query: LibraryQuery) { return this.learning.library(req.actor.id, query); }
  @Get('summary') @UseGuards(UserGuard) summary(@Req() req:AuthRequest){return this.learning.summary(req.actor.id);}
  @Post('lessons/:id/progress') @UseGuards(UserGuard) progress(@Param('id', ParseUUIDPipe) id: string, @Body() dto: ProgressDto, @Req() req: AuthRequest) { return this.learning.progress(id, req.actor.id, dto); }
  @Get('membership') @UseGuards(UserGuard) membership(@Req() req: AuthRequest) { return this.learning.membership(req.actor.id); }
  @Get('plans') plans() { return this.learning.plans(); }
}
