import 'reflect-metadata';
import { Controller, Get, Module, ValidationPipe } from '@nestjs/common';
import { AdminAudit } from './admin-audit.js';
import { APP_INTERCEPTOR } from '@nestjs/core';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { Database } from './database.js';
import { MembershipBenefitsService, MembershipBenefitsController, MembershipBenefitsAdminController } from './membership-benefits.js';
import { MembershipSalesService, MembershipSalesController, MembershipOrdersAdminController } from './membership-sales.js';
import { CatalogController, CatalogService } from './catalog.js';
import { AuthService, AdminGuard, UserGuard, OptionalUserGuard, AdminAuthController } from './auth.js';
import { LearningController, LearningService } from './learning.js';
import { CurriculumAdminController, CurriculumAdminService } from './curriculum-admin.js';
import { MediaController, MediaService } from './media.js';
import { ShoppingController, ShoppingAdminController, ShoppingService } from './shopping.js';
import { OrdersController, OrdersAdminController, OrdersService } from './orders.js';
import { ProductSalesService, ProductSalesController, ProductOrdersAdminController } from './product-sales.js';
import { IdentityController, IdentityService } from './identity.js';
import { PersonalController } from './personal.js';
import { AdminController, AdminService } from './admin.js';
import { pathToFileURL } from 'node:url';
import { DomainController, DomainService } from './domain.js';
import { TeachingAdminController, TeachingController, TeachingService } from './teaching.js';
import { CommentAdminController, ArticleInteractionController, ContentService } from './content.js';
import { ReadingController, DiscoveryController, DiscoveryService } from './discovery.js';
import { EditorialController, LiveDiscoveryAdminController } from './editorial.js';
import { ProgressionController } from './progression.js';
import { FeedbackController, FeedbackAdminController, FeedbackService } from './feedback.js';
import { PracticesController, PracticesAdminController, PracticesService } from './practices.js';
import { QuestionsController, QuestionsAdminController, QuestionsService } from './questions.js';
import { ForumController, ForumAdminController, ForumService } from './forum.js';
import { ShareController, ShareService } from './share.js';
import { validateProductionConfig } from './runtime-config.js';
import { CourseReviewsService, CourseReviewsController, CourseReviewsAdminController } from './course-reviews.js';
import { CourseSalesService, CourseSalesController, CourseOrdersAdminController, WechatCallbackController, AlipayCallbackController } from './course-sales.js';
import { CourseVersionsService, CourseVersionsController, CourseVersionsAdminController } from './course-versions.js';
import { WechatPayService } from './wechat-pay.js';
import { PaymentChannels } from './payment-channels.js';
import { AlipayService } from './alipay.js';
import { AppleStoreService } from './apple-store.js';
import { AppleCommerceService, AppleCommerceController, AppleCallbackController, AppleProductsController, AppleTransactionsController, AppleMembershipProductsController } from './apple-commerce.js';
import { AppleMembershipService } from './apple-membership.js';
import { randomUUID } from 'node:crypto';
import { AdminPermissions } from './admin-permissions.js';
import { AdminManagement, ManagementController } from './admin-management.js';
import { SystemConfig, ConfigController, PublicConfigController } from './system-config.js';
import { EventsAdmin, EventsAdminController } from './events-admin.js';

@Controller('health')
class HealthController {
  constructor(private readonly db: Database) {}
  @Get() async health() {
    await this.db.$queryRaw`SELECT 1`;
    return { status: 'ok', service: 'daoxue-api' };
  }
}

@Module({ controllers: [ProductSalesController, ProductOrdersAdminController, AppleMembershipProductsController, MembershipSalesController, MembershipOrdersAdminController, MembershipBenefitsController, MembershipBenefitsAdminController, AppleCommerceController, AppleCallbackController, AppleProductsController, AppleTransactionsController, CourseVersionsController, CourseVersionsAdminController, ManagementController, ConfigController, PublicConfigController, EventsAdminController, CourseSalesController, CourseOrdersAdminController, WechatCallbackController, AlipayCallbackController, CourseReviewsController, CourseReviewsAdminController, ForumController, ForumAdminController, HealthController, ProgressionController, FeedbackController, FeedbackAdminController, PracticesController, PracticesAdminController, QuestionsController, QuestionsAdminController, CatalogController, AdminAuthController, AdminController, IdentityController, PersonalController, LearningController, CurriculumAdminController, MediaController, ShoppingController, ShoppingAdminController, OrdersController, OrdersAdminController, DomainController, TeachingAdminController, TeachingController, CommentAdminController, ArticleInteractionController, ReadingController, DiscoveryController, ShareController, EditorialController, LiveDiscoveryAdminController], providers: [ProductSalesService, {provide:"PRODUCT_SALES",useExisting:ProductSalesService}, AppleMembershipService, MembershipSalesService, {provide:"MEMBERSHIP_SALES",useExisting:MembershipSalesService}, MembershipBenefitsService, {provide:APP_INTERCEPTOR,useClass:AdminAudit},AppleStoreService, AppleCommerceService, {provide:'APPLE_COMMERCE',useExisting:AppleCommerceService}, AdminPermissions, AdminManagement, SystemConfig, EventsAdmin, CourseVersionsService, WechatPayService, AlipayService, PaymentChannels, CourseSalesService, CourseReviewsService, ForumService, Database, FeedbackService, PracticesService, QuestionsService, CatalogService, AuthService, AdminGuard, UserGuard, OptionalUserGuard, AdminService, IdentityService, LearningService, CurriculumAdminService, MediaService, ShoppingService, OrdersService, DomainService, TeachingService, ContentService, ShareService, DiscoveryService] })
class AppModule {}

export async function createApp(logger: false | undefined = undefined) {
  validateProductionConfig(process.env);
  const app = await NestFactory.create(AppModule, { logger, rawBody:true });
  if(process.env.TRUST_PROXY)app.getHttpAdapter().getInstance().set('trust proxy',process.env.TRUST_PROXY.split(','));
  app.use(helmet());
  app.use((req: {requestId?:string}, res: {setHeader:(key:string,value:string)=>void}, next:()=>void) => { req.requestId=randomUUID();res.setHeader('X-Request-ID',req.requestId);next(); });
  app.enableCors({ origin: (process.env.CORS_ORIGINS ?? '').split(',').filter(Boolean), credentials: true });
  app.setGlobalPrefix('api/v1');
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
  app.enableShutdownHooks();
  if (process.env.NODE_ENV !== 'production') {
    const spec = SwaggerModule.createDocument(app, new DocumentBuilder().setTitle('道学书院 API').setVersion('1').build());
    SwaggerModule.setup('api/docs', app, spec);
  }
  return app;
}

async function main() {
  const app = await createApp();
  await app.listen(Number(process.env.PORT ?? 3000), process.env.API_HOST ?? '127.0.0.1');
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : 'API startup failed');
  process.exitCode = 1;
});
