import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { Type } from 'class-transformer';
import { IsInt, IsOptional, Max, Min } from 'class-validator';
import { UserGuard, type AuthRequest } from './auth.js';
import { Database } from './database.js';
class ProgressionPage {
  @IsOptional() @Type(()=>Number) @IsInt() @Min(1) @Max(10000) page=1;
  @IsOptional() @Type(()=>Number) @IsInt() @Min(1) @Max(50) size=20;
}
@Controller('me/progression') @UseGuards(UserGuard)
export class ProgressionController {
  constructor(private readonly db:Database){}
  @Get() async summary(@Req() req:AuthRequest){
    const [account,growth]=await this.db.$transaction([this.db.pointsAccount.findUnique({where:{userId:req.actor.id}}),this.db.growthLedger.aggregate({where:{userId:req.actor.id},_sum:{delta:true}})]);
    const value=Math.max(0,growth._sum.delta??0);
    return{points:String(account?.balance??0),reserved:String(account?.reserved??0),available:String((account?.balance??0n)-(account?.reserved??0n)),growth:value,level:value>=500?'实践者':value>=100?'研习者':'初学者',nextLevelAt:value>=500?null:value>=100?500:100,redemptionAvailable:false};
  }
  @Get('points') async points(@Req() req:AuthRequest,@Query() query:ProgressionPage){
    const account=await this.db.pointsAccount.findUnique({where:{userId:req.actor.id}});if(!account)return{items:[],total:0};
    const where={accountId:account.id};const [rows,total]=await this.db.$transaction([this.db.pointsLedger.findMany({where,orderBy:[{createdAt:'desc'},{id:'desc'}],skip:(query.page-1)*query.size,take:query.size,select:{id:true,delta:true,balanceAfter:true,reason:true,createdAt:true}}),this.db.pointsLedger.count({where})]);return{items:rows.map(r=>({...r,delta:String(r.delta),balanceAfter:String(r.balanceAfter)})),total};
  }
  @Get('growth') async growth(@Req() req:AuthRequest,@Query() query:ProgressionPage){
    const where={userId:req.actor.id};const [items,total]=await this.db.$transaction([this.db.growthLedger.findMany({where,orderBy:[{createdAt:'desc'},{id:'desc'}],skip:(query.page-1)*query.size,take:query.size,select:{id:true,delta:true,reason:true,createdAt:true}}),this.db.growthLedger.count({where})]);return{items,total};
  }
}
