import { previewLoginConfig } from './preview-login.js';

export function validateProductionConfig(env:NodeJS.ProcessEnv){
  previewLoginConfig(env);
  if(env.NODE_ENV!=='production')return;
  if(env.PRODUCT_SALES_ENABLED!==undefined&&!['true','false'].includes(env.PRODUCT_SALES_ENABLED))throw new Error('PRODUCT_SALES_ENABLED must be true or false');
  if(env.PRODUCT_SALES_ENABLED==='true'&&env.COURSE_PAYMENT_WORKER_ENABLED==='false')throw new Error('Product sales require payment recovery');
  if(env.APPLE_MEMBERSHIP_SALES_ENABLED!==undefined&&!['true','false'].includes(env.APPLE_MEMBERSHIP_SALES_ENABLED))throw new Error('APPLE_MEMBERSHIP_SALES_ENABLED must be true or false');
  if(env.APPLE_MEMBERSHIP_SALES_ENABLED==='true'&&(env.APPLE_IAP_ENABLED!=='true'||env.APPLE_NATIVE_PURCHASE_READY!=='true'||env.COURSE_PAYMENT_WORKER_ENABLED==='false'))throw new Error('Apple membership sales require verified Apple identity, native purchase readiness and receipt recovery');
  if(env.DEV_OTP_CODE||env.ORDER_RESERVATION_PREVIEW==='true')throw new Error('Production forbids DEV_OTP_CODE and ORDER_RESERVATION_PREVIEW');
  if(env.SMS_ENABLED!==undefined&&!['true','false'].includes(env.SMS_ENABLED))throw new Error('SMS_ENABLED must be true or false');
  const smsFields=env.SMS_ENABLED==='false'?[]:['SMS_SECRET_ID','SMS_SECRET_KEY','SMS_SDK_APP_ID','SMS_TEMPLATE_ID','SMS_SIGN_NAME'];
  for(const name of ['DATABASE_URL','CORS_ORIGINS','PUBLIC_API_URL','OTP_HASH_SECRET','DOMAIN_ENCRYPTION_KEY','MEDIA_TOKEN_SECRET',...smsFields]){
    const value=env[name];if(!value||/CHANGE_ME|REPLACE_ME/.test(value))throw new Error('Production requires '+name);
  }
  for(const name of ['DOMAIN_ENCRYPTION_KEY','MEDIA_TOKEN_SECRET'])if(!/^[a-fA-F0-9]{64}$/.test(env[name]!))throw new Error(name+' must be a 32-byte hex key');
  if(Buffer.byteLength(env.OTP_HASH_SECRET!)<32)throw new Error('OTP_HASH_SECRET must contain at least 32 bytes');
  const db=new URL(env.DATABASE_URL!);if(!['postgres:','postgresql:'].includes(db.protocol)||!db.username||!db.password||db.pathname==='/')throw new Error('Invalid production DATABASE_URL');
  const publicUrl=new URL(env.PUBLIC_API_URL!);if(publicUrl.protocol!=='https:'||publicUrl.username||publicUrl.password||publicUrl.search||publicUrl.hash||!publicUrl.pathname.replace(/\/$/,'').endsWith('/api/v1'))throw new Error('PUBLIC_API_URL must use HTTPS and end with /api/v1');
  for(const value of env.CORS_ORIGINS!.split(',')){const origin=new URL(value);if(origin.protocol!=='https:'||origin.origin!==value)throw new Error('CORS_ORIGINS must contain exact HTTPS origins');}
  if(env.PUBLIC_APP_URL&&new URL(env.PUBLIC_APP_URL).protocol!=='https:')throw new Error('PUBLIC_APP_URL must use HTTPS');
  if(env.TRUST_PROXY==='true'||env.TRUST_PROXY==='*')throw new Error('TRUST_PROXY must name the proxy address or subnet');
}
