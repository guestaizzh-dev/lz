import { Body, Controller, Get, Injectable, NotFoundException, Param, Post, Res } from '@nestjs/common';
import { IsIn, IsOptional, IsString, IsUUID, Length } from 'class-validator';
import type { Response } from 'express';
import { DiscoveryService, contentTypes } from './discovery.js';

class ShareDto {
  @IsIn(contentTypes) resourceType!: string;
  @IsUUID() resourceId!: string;
  // Old clients send metadata; it is never trusted or persisted.
  @IsOptional() @IsString() @Length(0, 200) title?: string;
  @IsOptional() @IsString() @Length(0, 1000) description?: string;
  @IsOptional() @IsString() @Length(0, 2000) coverUrl?: string;
}
const escapeHtml = (value: string) => value.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
@Injectable()
export class ShareService {
  constructor(private readonly discovery: DiscoveryService) {}
  async resolve(code: string) {
    const [type, id, extra] = code.split('_');
    if (extra || !contentTypes.includes(type!) || !/^[a-f0-9-]{36}$/i.test(id ?? '')) throw new NotFoundException('分享链接无效');
    const item = await this.discovery.publicItem(id!, type!);
    return { resourceType: item.type, resourceId: item.id, title: item.title, description: item.summary, coverUrl: item.cover };
  }
  async create(dto: ShareDto) {
    const code = `${dto.resourceType}_${dto.resourceId}`;
    await this.resolve(code);
    const base = (process.env.PUBLIC_API_URL ?? 'http://127.0.0.1:3000/api/v1').replace(/\/$/, '');
    const url = `${base}/share/open/${code}`;
    return { code, url, shortUrl: url, development: process.env.NODE_ENV !== 'production' };
  }
}
@Controller('share')
export class ShareController {
  constructor(private readonly service: ShareService) {}
  @Post('links') create(@Body() dto: ShareDto) { return this.service.create(dto); }
  @Get('links/:code/resolve') resolve(@Param('code') code: string) { return this.service.resolve(code); }
  @Get('open/:code') async open(@Param('code') code: string, @Res() res: Response) {
    const item = await this.service.resolve(code);
    const web = process.env.PUBLIC_APP_URL;
    const link = web && /^https?:\/\//.test(web) ? `${web.replace(/\/$/, '')}/#/pages/shared/index?code=${encodeURIComponent(code)}` : null;
    res.setHeader('Cache-Control', 'no-store');
    res.type('html').send(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(item.title)} · 老子道学书院</title><body style="max-width:640px;margin:64px auto;padding:24px;font-family:serif;color:#17292d;background:#faf8f2"><p>老子道学书院</p><h1>${escapeHtml(item.title)}</h1><p>${escapeHtml(item.description)}</p>${link ? `<a href="${escapeHtml(link)}">打开书院阅读</a>` : '<p>请在书院 App 中查看完整内容。</p>'}</body></html>`);
  }
}
